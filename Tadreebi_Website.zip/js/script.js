
// Simple navbar interaction script
console.log("Tadreebi Website Loaded");
